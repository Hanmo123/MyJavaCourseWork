public class Question16 {
    public static void main(String[] args) {
        System.out.println((char) ((int) (Math.random() * 26) + 65));
    }
}