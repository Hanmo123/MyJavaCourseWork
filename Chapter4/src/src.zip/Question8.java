import java.util.Scanner;

public class Question8 {
    public static void main(String[] args) {
        System.out.println((char) new Scanner(System.in).nextInt());
    }
}